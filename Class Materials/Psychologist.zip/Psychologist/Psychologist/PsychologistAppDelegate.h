//
//  PsychologistAppDelegate.h
//  Psychologist
//
//  Created by CS193p Instructor on 4/24/12.
//  Copyright (c) 2012 Stanford University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PsychologistAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
