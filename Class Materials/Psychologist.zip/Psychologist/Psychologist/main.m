//
//  main.m
//  Psychologist
//
//  Created by CS193p Instructor on 4/24/12.
//  Copyright (c) 2012 Stanford University. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PsychologistAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PsychologistAppDelegate class]));
    }
}
