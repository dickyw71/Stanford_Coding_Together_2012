//
//  ImageViewController.h
//  Shutterbug
//
//  Created by CS193p Instructor on 5/3/12.
//  Copyright (c) 2012 Stanford University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageViewController : UIViewController
@property (nonatomic, strong) NSURL *imageURL;
@end
