//
//  FlickrAPIKey.h
//
//  Created for Stanford CS193p Spring 2012.
//  Copyright 2011 Stanford University. All rights reserved.
//
//  Get your own key!
//  No Flickr fetches will work without the API Key!
//

#define FlickrAPIKey @""
