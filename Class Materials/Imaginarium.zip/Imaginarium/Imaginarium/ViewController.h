//
//  ViewController.h
//  Imaginarium
//
//  Created by CS193p Instructor on 4/26/12.
//  Copyright (c) 2012 Stanford University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
